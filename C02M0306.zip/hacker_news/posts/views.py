from datetime import datetime
from django.forms import modelform_factory
from django.shortcuts import redirect, render
from .models import Post,Job
# Create your views here.
def home(request):
    
    return render(request, 'posts/home.html',{
        #Order by
        #  "news": Post.objects.all().order_by('publicationDate')
        # "news": Post.objects.all().order_by('author')
        # "news": Post.objects.all().order_by('points')
        # "news": Post.objects.all().order_by('-points')

        # Filter
        "news": Post.objects.filter(points__lte=10)
    #  "news": Post.objects.filter(points__gte=10)

    #Create
    # p = Post.objects.create(id=100,title="Hola Mundo", author="Dr. Goku",publicationDate=datetime.now(),points=22,link="www.creahana.com")
    # p.save(force_insert=True)
    })

def jobs(request):
    return render(request,'posts/jobs.html',{
        "jobs": Job.objects.all()
    })

AddForm = modelform_factory(Post)
def addPost(request):
    form = AddForm(request.POST)
   
    return render(request,"posts/add.html",{"form":form})
