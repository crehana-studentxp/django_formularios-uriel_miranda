(function () {
  function init() {
    const upvote = document.querySelectorAll(".caret");
    for (let i = 0; i < upvote.length; i++) {
      upvote[i].addEventListener("click", function (evt) {
        alert(upvote[i].getAttribute('data-hn'));
      });
    }
  }

  init();
})();
