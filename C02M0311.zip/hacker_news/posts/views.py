from datetime import datetime
from django.forms import modelform_factory
from django.shortcuts import redirect, render
from .models import Post,Job
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,authenticate

# Create your views here.
def home(request):
    
    return render(request, 'posts/home.html',{
        #Order by
        #  "news": Post.objects.all().order_by('publicationDate')
        # "news": Post.objects.all().order_by('author')
        # "news": Post.objects.all().order_by('points')
        # "news": Post.objects.all().order_by('-points')

        # Filter
        "news": Post.objects.filter(points__lte=10)
    #  "news": Post.objects.filter(points__gte=10)

    #Create
    # p = Post.objects.create(id=100,title="Hola Mundo", author="Dr. Goku",publicationDate=datetime.now(),points=22,link="www.creahana.com")
    # p.save(force_insert=True)
    })

def jobs(request):
    return render(request,'posts/jobs.html',{
        "jobs": Job.objects.all()
    })

AddForm = modelform_factory(Post,exclude=['publicationDate','points','author'])
def addPost(request):
    if request.method == 'POST':
        form = AddForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.author = request.user;
            obj.save()
            form = AddForm()
            return redirect('home')
            
    else:
        form = AddForm(request.POST)
        return render(request,"posts/add.html",{'form':form})

def sing_up(request):
    form = UserCreationForm(request.POST)
    if form.is_valid():
        form.save()
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(username=username,password=password)
        login(request,user)
        return redirect("home")
    return render(request,"registration/register.html",{"form":form})

